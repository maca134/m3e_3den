name = "M3Editor - 3DEN";
author = "maca134";
actionName = "Website";
action = "https://github.com/maca134/armaext";
overview = "Modded version of M3E 3DEN Editor by HellBz from Source of Maca123";
picture = "logo_m3e_3den.paa";
logo = "logo_m3e_3den.paa";
logoOver = "logo_m3e_3den.paa";




