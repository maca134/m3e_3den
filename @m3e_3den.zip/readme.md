# M3Editor - 3DEN - [Downloads](https://github.com/maca134/m3e_3den/releases)
A mod to extend 3DEN to make it easier to add objects/traders to a map in ARMA 3

[Video](https://www.youtube.com/watch?v=05p-bJgS1mY)